# "1st program"
print((9**0.5)*5)
# "2nd program"
print(9.99>9.98 and 1000!=1000.1)
# "3rd program"
print((2*2+2)==2*(2+2))
# "4th program"
print(int(float('123.456')*10-1230.56))

